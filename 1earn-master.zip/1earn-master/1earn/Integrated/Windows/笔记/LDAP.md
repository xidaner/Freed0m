# LDAP

---

常用缩写词
- DN:Distinguished Name
- CN:Common Name
- OU:Organizational Unit
- DC:Domain Component
- ACE:Access Control Entries
- ACL:Access Control List

LDAP 连接服务器的连接字串格式为：ldap://servername/DN

其中 DN 有三个属性，分别是 CN、OU 和 DC
