# VPN/Security

> 分类参考科来网络通讯协议图

---

# 网络层

**相关文章**
- [GRE、PPTP、L2TP隧道协议](https://blog.csdn.net/eydwyz/article/details/54879808)

## GRE

**相关文章**
- [浅析GRE协议（通用路由封装协议）](https://blog.csdn.net/mary19920410/article/details/72303641)

---

# 数据链路层

## PPTP

**相关文章**
- [PPTP 理解以及报文的分析](https://blog.csdn.net/zhaqiwen/article/details/10083025)
