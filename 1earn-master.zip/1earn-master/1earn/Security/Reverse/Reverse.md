# Reverse

---

# 文件

- [文件头](./FILE/文件头.md)

# 软件逆向

**工具**
- [IDA](../安全工具/IDA.md)
- [Ghidra](../安全工具/Ghidra.md)

**资源**
- [mentebinaria/retoolkit](https://github.com/mentebinaria/retoolkit) - 离线逆向工具安装包合集
